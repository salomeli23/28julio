import React, { useState, useRef, useEffect } from 'react';
import { Camera, RotateCcw, CheckCircle, ArrowLeft, User, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { DiagnosisData, CapturedImage } from '../types/diagnosis';
import { analyzeImages } from '../utils/imageAnalysis';

interface CameraModuleProps {
  onComplete: (data: DiagnosisData) => void;
  onBack: () => void;
}

const photoSteps = [
  {
    id: 'front',
    title: 'Vista Frontal',
    description: 'Colócate frente a la cámara mostrando tu rostro y cabello completo',
    instruction: 'Mira directamente a la cámara con el cabello visible'
  },
  {
    id: 'side',
    title: 'Vista Lateral',
    description: 'Gira tu cabeza hacia la derecha mostrando el perfil',
    instruction: 'Muestra el perfil derecho de tu cabello'
  },
  {
    id: 'back',
    title: 'Vista Posterior',
    description: 'Da la espalda a la cámara mostrando la nuca y largo del cabello',
    instruction: 'Muestra la parte posterior de tu cabello'
  },
  {
    id: 'scalp',
    title: 'Cuero Cabelludo',
    description: 'Acerca la cámara para mostrar las raíces y cuero cabelludo',
    instruction: 'Enfoca las raíces y el cuero cabelludo'
  }
];

const CameraModule: React.FC<CameraModuleProps> = ({ onComplete, onBack }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [capturedImages, setCapturedImages] = useState<CapturedImage[]>([]);
  const [isCapturing, setIsCapturing] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [personDetected, setPersonDetected] = useState(false);
  const [faceDetector, setFaceDetector] = useState<any>(null);
  const [detectionInterval, setDetectionInterval] = useState<NodeJS.Timeout | null>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [detectionError, setDetectionError] = useState<string | null>(null);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const detectionCanvasRef = useRef<HTMLCanvasElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    startCamera();
    initializeFaceDetection();
    return () => {
      stopCamera();
      stopDetection();
    };
  }, []);

  const initializeFaceDetection = async () => {
    try {
      // Verificar si el navegador soporta Face Detection API
      if ('FaceDetector' in window) {
        const detector = new (window as any).FaceDetector({
          maxDetectedFaces: 5,
          fastMode: false
        });
        setFaceDetector(detector);
        startPersonDetection();
      } else {
        // Fallback: usar detección basada en análisis de imagen
        console.log('Face Detection API no disponible, usando detección alternativa');
        startAlternativeDetection();
      }
    } catch (error) {
      console.error('Error inicializando detección facial:', error);
      setDetectionError('Error en la detección facial');
      startAlternativeDetection();
    }
  };

  const startPersonDetection = () => {
    if (detectionInterval) clearInterval(detectionInterval);
    
    const interval = setInterval(async () => {
      await detectPerson();
    }, 1000);
    
    setDetectionInterval(interval);
  };

  const startAlternativeDetection = () => {
    if (detectionInterval) clearInterval(detectionInterval);
    
    const interval = setInterval(() => {
      detectPersonAlternative();
    }, 1000);
    
    setDetectionInterval(interval);
  };

  const detectPerson = async () => {
    if (!videoRef.current || !detectionCanvasRef.current || !faceDetector) return;

    try {
      const video = videoRef.current;
      const canvas = detectionCanvasRef.current;
      const ctx = canvas.getContext('2d');
      
      if (!ctx || video.videoWidth === 0 || video.videoHeight === 0) return;

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0);

      const faces = await faceDetector.detect(canvas);
      
      if (faces && faces.length > 0) {
        setPersonDetected(true);
        setDetectionError(null);
        
        // Verificar posición según el paso actual
        const isValidPosition = validatePersonPosition(faces[0]);
        if (!isValidPosition) {
          speakInstruction(`Ajusta tu posición para ${photoSteps[currentStep].title}`);
        }
      } else {
        setPersonDetected(false);
      }
    } catch (error) {
      console.error('Error en detección facial:', error);
      setPersonDetected(false);
    }
  };

  const detectPersonAlternative = () => {
    if (!videoRef.current || !detectionCanvasRef.current) return;

    try {
      const video = videoRef.current;
      const canvas = detectionCanvasRef.current;
      const ctx = canvas.getContext('2d');
      
      if (!ctx || video.videoWidth === 0 || video.videoHeight === 0) return;

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0);

      // Análisis básico de imagen para detectar movimiento/presencia
      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const hasMovement = analyzeImageForMovement(imageData);
      
      setPersonDetected(hasMovement);
    } catch (error) {
      console.error('Error en detección alternativa:', error);
      setPersonDetected(false);
    }
  };

  const analyzeImageForMovement = (imageData: ImageData): boolean => {
    const data = imageData.data;
    let totalBrightness = 0;
    let pixelCount = 0;
    
    // Analizar brillo promedio y variación
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      const brightness = (r + g + b) / 3;
      totalBrightness += brightness;
      pixelCount++;
    }
    
    const avgBrightness = totalBrightness / pixelCount;
    
    // Si hay suficiente variación de brillo, probablemente hay una persona
    return avgBrightness > 30 && avgBrightness < 200;
  };

  const validatePersonPosition = (face: any): boolean => {
    const step = photoSteps[currentStep];
    const faceBox = face.boundingBox;
    
    // Validaciones básicas según el tipo de foto
    switch (step.id) {
      case 'front':
        // Para vista frontal, el rostro debe estar centrado
        return faceBox.x > 0.2 && faceBox.x < 0.8;
      case 'side':
        // Para vista lateral, el rostro debe estar hacia un lado
        return faceBox.x < 0.3 || faceBox.x > 0.7;
      case 'back':
        // Para vista posterior, no debería detectar rostro claramente
        return true; // Permitir cualquier detección para vista posterior
      case 'scalp':
        // Para cuero cabelludo, puede ser cualquier posición
        return true;
      default:
        return true;
    }
  };

  const stopDetection = () => {
    if (detectionInterval) {
      clearInterval(detectionInterval);
      setDetectionInterval(null);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: { ideal: 1080 },
          height: { ideal: 1920 },
          facingMode: 'user'
        }
      });
      
      setCameraStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
    }
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
    }
  };

  const speakInstruction = (text: string) => {
    if ('speechSynthesis' in window) {
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'es-ES';
      utterance.rate = 0.8;
      speechSynthesis.speak(utterance);
    }
  };

  const startCountdown = () => {
    if (!personDetected) {
      speakInstruction('Por favor, colócate frente a la cámara para que pueda detectarte');
      return;
    }

    setIsCapturing(true);
    speakInstruction(`Preparando captura ${photoSteps[currentStep].title}. 5, 4, 3, 2, 1`);
    
    let count = 5;
    setCountdown(count);
    
    const timer = setInterval(() => {
      count--;
      setCountdown(count);
      
      if (count === 0) {
        clearInterval(timer);
        capturePhoto();
      }
    }, 1000);
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0);
        
        canvas.toBlob((blob) => {
          if (blob) {
            const url = URL.createObjectURL(blob);
            const newImage: CapturedImage = {
              id: Date.now().toString(),
              type: photoSteps[currentStep].id as any,
              url,
              timestamp: Date.now()
            };
            
            setCapturedImages(prev => [...prev, newImage]);
            setIsCapturing(false);
            setCountdown(0);
            
            speakInstruction('Foto capturada correctamente');
            
            if (currentStep < photoSteps.length - 1) {
              setTimeout(() => {
                setCurrentStep(currentStep + 1);
                speakInstruction(`Siguiente paso: ${photoSteps[currentStep + 1].instruction}`);
              }, 1500);
            } else {
              processImages();
            }
          }
        }, 'image/jpeg', 0.8);
      }
    }
  };

  const processImages = async () => {
    setIsProcessing(true);
    speakInstruction('Procesando imágenes y generando diagnóstico');
    
    // Simular procesamiento de 10 segundos
    await new Promise(resolve => setTimeout(resolve, 10000));
    
    const diagnosis = analyzeImages(capturedImages);
    onComplete(diagnosis);
  };

  const retakePhoto = () => {
    const lastImage = capturedImages[capturedImages.length - 1];
    if (lastImage) {
      URL.revokeObjectURL(lastImage.url);
      setCapturedImages(prev => prev.slice(0, -1));
      speakInstruction('Foto eliminada. Puedes tomar una nueva');
    }
  };

  const currentPhotoStep = photoSteps[currentStep];

  if (isProcessing) {
    return (
      <div className="h-screen relative overflow-hidden bg-black">
        {/* Video de fondo */}
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover opacity-30"
        >
          <source 
            src="https://res.cloudinary.com/dewemwkqf/video/upload/v1753053530/20250719_1856_Animated_Expressions_remix_01k0jhvdete0vb3ybaccwedf5c_uodh4d.mp4" 
            type="video/mp4" 
          />
        </video>
        
        {/* Overlay oscuro */}
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        
        {/* Contenido */}
        <div className="relative z-10 h-full flex items-center justify-center">
          <div className="text-center text-pure-white">
            <div className="animate-spin rounded-full h-32 w-32 border-b-4 border-bright-gold mx-auto mb-8"></div>
            <h2 className="text-4xl font-bold mb-4 text-pure-white">Procesando Imágenes</h2>
            <p className="text-xl text-pure-white opacity-90">Generando tu diagnóstico personalizado...</p>
            <div className="mt-8 flex justify-center">
              <div className="flex space-x-2">
                <div className="w-3 h-3 bg-bright-gold rounded-full animate-bounce"></div>
                <div className="w-3 h-3 bg-bright-gold rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                <div className="w-3 h-3 bg-bright-gold rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen relative bg-black overflow-hidden">
      <button
        onClick={onBack}
        className="absolute top-4 left-4 z-20 bg-black bg-opacity-50 text-white p-3 rounded-full hover:bg-opacity-70 transition-all"
      >
        <ArrowLeft className="w-6 h-6" />
      </button>

      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="absolute inset-0 w-full h-full object-cover"
      />

      <canvas ref={canvasRef} className="hidden" />
      <canvas ref={detectionCanvasRef} className="hidden" />

      {/* Overlay de información */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black">
        {/* Información del paso actual */}
        <div className="absolute top-20 left-0 right-0 text-center text-white px-8">
          <div className="bg-soft-beige bg-opacity-90 rounded-2xl p-6 max-w-2xl mx-auto">
            <h2 className="text-3xl font-bold text-intense-black mb-2">
              {currentPhotoStep.title} ({currentStep + 1}/4)
            </h2>
            <p className="text-xl text-intense-black opacity-80 mb-4">{currentPhotoStep.description}</p>
            <div className="flex items-center justify-center gap-2 text-lg text-intense-black">
              {personDetected ? (
                <>
                  <Eye className="w-6 h-6 text-bright-gold" />
                  <span className="text-bright-gold">✓ Persona detectada correctamente</span>
                </>
              ) : (
                <>
                  <EyeOff className="w-6 h-6 text-bright-gold" />
                  <span className="text-bright-gold">⚠ Colócate frente a la cámara</span>
                </>
              )}
            </div>
            {detectionError && (
              <p className="text-bright-gold text-sm mt-2">
                {detectionError} - Usando detección alternativa
              </p>
            )}
          </div>
        </div>

        {/* Countdown */}
        {countdown > 0 && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-8xl font-bold text-white animate-pulse">
              {countdown}
            </div>
          </div>
        )}

        {/* Controles inferiores */}
        <div className="absolute bottom-8 left-0 right-0 flex justify-center items-center gap-6">
          {!isCapturing ? (
            <>
              <button
                onClick={startCountdown}
                disabled={!personDetected}
                className={`p-6 rounded-full text-white transition-all duration-300 ${
                  !personDetected 
                    ? 'bg-gray-600 opacity-50 cursor-not-allowed' 
                    : 'bg-red-600 hover:bg-red-700 hover:scale-110 shadow-lg'
                }`}
              >
                <Camera className="w-12 h-12" />
              </button>
              
              {!personDetected && (
                <div className="bg-red-600 bg-opacity-80 px-6 py-3 rounded-full">
                  <span className="text-white text-lg font-semibold">
                    Esperando detección...
                  </span>
                </div>
              )}
              
              {capturedImages.length > 0 && (
                <button
                  onClick={retakePhoto}
                  className="bg-yellow-600 p-4 rounded-full text-white hover:bg-yellow-700 transition-all"
                >
                  <RotateCcw className="w-8 h-8" />
                </button>
              )}
            </>
          ) : (
            <div className="bg-black bg-opacity-70 px-8 py-4 rounded-full">
              <span className="text-white text-xl">Capturando...</span>
            </div>
          )}
        </div>

        {/* Indicador de detección en tiempo real */}
        <div className="absolute top-4 right-4 z-20">
          <div className={`w-4 h-4 rounded-full ${
            personDetected ? 'bg-green-400 animate-pulse' : 'bg-red-400'
          }`}></div>
        </div>

        {/* Progreso */}
        <div className="absolute bottom-32 left-0 right-0 px-8">
          <div className="flex gap-2 justify-center">
            {photoSteps.map((_, index) => (
              <div
                key={index}
                className={`w-4 h-4 rounded-full transition-all ${
                  index < capturedImages.length
                    ? 'bg-green-500'
                    : index === currentStep
                    ? 'bg-purple-500'
                    : 'bg-gray-500'
                }`}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CameraModule;