// Utilidades para detección de personas y validación de posición

export interface DetectedFace {
  boundingBox: {
    x: number;
    y: number;
    width: number;
    height: number;
  };
  landmarks?: Array<{
    type: string;
    locations: Array<{ x: number; y: number }>;
  }>;
}

export class PersonDetectionService {
  private static instance: PersonDetectionService;
  private faceDetector: any = null;
  private isInitialized = false;

  static getInstance(): PersonDetectionService {
    if (!PersonDetectionService.instance) {
      PersonDetectionService.instance = new PersonDetectionService();
    }
    return PersonDetectionService.instance;
  }

  async initialize(): Promise<boolean> {
    try {
      if ('FaceDetector' in window) {
        this.faceDetector = new (window as any).FaceDetector({
          maxDetectedFaces: 5,
          fastMode: false
        });
        this.isInitialized = true;
        return true;
      }
      return false;
    } catch (error) {
      console.error('Error inicializando Face Detection API:', error);
      return false;
    }
  }

  async detectFaces(canvas: HTMLCanvasElement): Promise<DetectedFace[]> {
    if (!this.isInitialized || !this.faceDetector) {
      throw new Error('Face detector no inicializado');
    }

    try {
      const faces = await this.faceDetector.detect(canvas);
      return faces.map((face: any) => ({
        boundingBox: {
          x: face.boundingBox.x / canvas.width,
          y: face.boundingBox.y / canvas.height,
          width: face.boundingBox.width / canvas.width,
          height: face.boundingBox.height / canvas.height
        },
        landmarks: face.landmarks
      }));
    } catch (error) {
      console.error('Error detectando rostros:', error);
      return [];
    }
  }

  validatePositionForStep(faces: DetectedFace[], stepId: string): {
    isValid: boolean;
    message: string;
  } {
    if (faces.length === 0) {
      return {
        isValid: false,
        message: 'No se detecta ninguna persona en la imagen'
      };
    }

    const face = faces[0];
    const { x, y, width, height } = face.boundingBox;

    switch (stepId) {
      case 'front':
        if (x < 0.2 || x > 0.6) {
          return {
            isValid: false,
            message: 'Centra tu rostro en la pantalla'
          };
        }
        if (width < 0.15) {
          return {
            isValid: false,
            message: 'Acércate más a la cámara'
          };
        }
        return { isValid: true, message: 'Posición correcta para vista frontal' };

      case 'side':
        if (x > 0.3 && x < 0.5) {
          return {
            isValid: false,
            message: 'Gira más hacia el lado derecho'
          };
        }
        return { isValid: true, message: 'Posición correcta para vista lateral' };

      case 'back':
        // Para vista posterior, la detección de rostro debería ser mínima
        if (width > 0.1) {
          return {
            isValid: false,
            message: 'Gira completamente de espaldas a la cámara'
          };
        }
        return { isValid: true, message: 'Posición correcta para vista posterior' };

      case 'scalp':
        if (y > 0.5) {
          return {
            isValid: false,
            message: 'Inclina la cabeza hacia abajo para mostrar el cuero cabelludo'
          };
        }
        return { isValid: true, message: 'Posición correcta para mostrar cuero cabelludo' };

      default:
        return { isValid: true, message: 'Posición aceptable' };
    }
  }

  // Detección alternativa basada en análisis de imagen
  detectPersonAlternative(imageData: ImageData): {
    detected: boolean;
    confidence: number;
  } {
    const data = imageData.data;
    const width = imageData.width;
    const height = imageData.height;
    
    let skinPixels = 0;
    let totalPixels = 0;
    let movementScore = 0;
    
    // Analizar colores de piel y variación
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      
      // Detectar tonos de piel aproximados
      if (this.isSkinTone(r, g, b)) {
        skinPixels++;
      }
      
      // Calcular variación de color (indicador de presencia)
      const brightness = (r + g + b) / 3;
      if (brightness > 50 && brightness < 200) {
        movementScore++;
      }
      
      totalPixels++;
    }
    
    const skinRatio = skinPixels / (totalPixels / 4);
    const movementRatio = movementScore / (totalPixels / 4);
    
    const confidence = Math.min((skinRatio * 2 + movementRatio) / 2, 1);
    const detected = confidence > 0.1;
    
    return { detected, confidence };
  }

  private isSkinTone(r: number, g: number, b: number): boolean {
    // Rangos aproximados para tonos de piel
    const skinRanges = [
      { rMin: 95, rMax: 255, gMin: 40, gMax: 200, bMin: 20, bMax: 150 },
      { rMin: 130, rMax: 255, gMin: 80, gMax: 220, bMin: 50, bMax: 180 },
      { rMin: 160, rMax: 255, gMin: 120, gMax: 240, bMin: 80, bMax: 200 }
    ];
    
    return skinRanges.some(range => 
      r >= range.rMin && r <= range.rMax &&
      g >= range.gMin && g <= range.gMax &&
      b >= range.bMin && b <= range.bMax
    );
  }
}