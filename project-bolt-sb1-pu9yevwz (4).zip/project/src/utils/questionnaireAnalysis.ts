import { DiagnosisData, HairAnalysis, ProductRecommendation, CareRoutine } from '../types/diagnosis';

export const analyzeQuestionnaire = (answers: Record<string, any>): DiagnosisData => {
  const analysis: HairAnalysis = {
    type: answers['hair-type'] || 'normal',
    texture: answers['hair-texture'] || 'liso',
    density: answers['hair-density'] || 'media',
    volume: answers['hair-density'] === 'alta' ? 'alto' : 
           answers['hair-density'] === 'baja' ? 'bajo' : 'medio',
    condition: determineCondition(answers)
  };

  const recommendations = generateRecommendations(analysis, answers);
  const routine = generateCareRoutine(analysis, answers);
  const tips = generateTips(analysis, answers);

  return {
    questionnaire: answers,
    analysis,
    recommendations,
    routine,
    tips,
    timestamp: Date.now()
  };
};

const determineCondition = (answers: Record<string, any>): 'excelente' | 'bueno' | 'regular' | 'necesita_atencion' => {
  const concerns = answers['hair-concerns'] || [];
  const treatments = answers['treatments'] || [];
  
  if (concerns.length === 0 && !treatments.includes('decoloracion')) {
    return 'excelente';
  } else if (concerns.length <= 2 && !treatments.includes('decoloracion')) {
    return 'bueno';
  } else if (concerns.length <= 4) {
    return 'regular';
  } else {
    return 'necesita_atencion';
  }
};

const generateRecommendations = (analysis: HairAnalysis, answers: Record<string, any>): ProductRecommendation[] => {
  const allRecommendations: ProductRecommendation[] = [];
  const concerns = answers['hair-concerns'] || [];
  const treatments = answers['treatments'] || [];
  
  // Productos Pantene según tipo de cabello
  if (analysis.type === 'graso') {
    allRecommendations.push({
      id: 'pantene-control-grasa',
      name: 'Pantene Pro-V Control de Grasa',
      type: 'shampoo',
      description: 'Shampoo especializado que limpia profundamente y controla el exceso de grasa sin resecar',
      benefits: ['Control de grasa hasta 72h', 'Limpieza profunda', 'Cabello ligero y fresco', 'Fórmula sin sulfatos'],
      usage: 'Aplicar sobre cabello húmedo, masajear suavemente y enjuagar',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/shampoo-pantene-pro-v-control-de-grasa'
    });
    allRecommendations.push({
      id: 'pantene-acondicionador-control-grasa',
      name: 'Pantene Pro-V Acondicionador Control de Grasa',
      type: 'acondicionador',
      description: 'Acondicionador ligero que hidrata sin agregar peso al cabello graso',
      benefits: ['Hidratación ligera', 'No agrega peso', 'Desenreda fácilmente', 'Control de grasa'],
      usage: 'Aplicar en medios y puntas, dejar actuar 2 minutos y enjuagar',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/acondicionador-pantene-pro-v-control-de-grasa'
    });
  } else if (analysis.type === 'seco') {
    allRecommendations.push({
      id: 'pantene-hidratacion-intensa',
      name: 'Pantene Pro-V Hidratación Intensa',
      type: 'shampoo',
      description: 'Shampoo con fórmula hidratante que nutre el cabello seco desde la raíz hasta las puntas',
      benefits: ['Hidratación profunda', 'Suavidad extrema', 'Brillo natural', 'Protección contra sequedad'],
      usage: 'Aplicar sobre cabello húmedo, masajear y enjuagar abundantemente',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/shampoo-pantene-pro-v-hidratacion-intensa'
    });
    allRecommendations.push({
      id: 'pantene-mascarilla-hidratante',
      name: 'Pantene Pro-V Mascarilla Hidratación Intensa',
      type: 'mascarilla',
      description: 'Tratamiento intensivo que restaura la hidratación del cabello seco y dañado',
      benefits: ['Hidratación 5x más intensa', 'Reparación profunda', 'Suavidad duradera', 'Brillo radiante'],
      usage: 'Aplicar 1-2 veces por semana después del shampoo, dejar actuar 3-5 minutos',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/mascarilla-pantene-pro-v-hidratacion-intensa'
    });
  } else if (analysis.type === 'mixto') {
    allRecommendations.push({
      id: 'pantene-equilibrio-perfecto',
      name: 'Pantene Pro-V Equilibrio Perfecto',
      type: 'shampoo',
      description: 'Fórmula balanceada que controla la grasa en raíces e hidrata medios y puntas',
      benefits: ['Balance perfecto', 'Control de grasa en raíces', 'Hidratación en puntas', 'Cabello equilibrado'],
      usage: 'Aplicar enfocándose en el cuero cabelludo, masajear y distribuir hasta las puntas',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/shampoo-pantene-pro-v-equilibrio-perfecto'
    });
  } else { // normal
    allRecommendations.push({
      id: 'pantene-clasico',
      name: 'Pantene Pro-V Clásico',
      type: 'shampoo',
      description: 'Cuidado completo para cabello normal que mantiene su salud y belleza natural',
      benefits: ['Limpieza suave', 'Nutrición balanceada', 'Brillo natural', 'Fortalecimiento'],
      usage: 'Aplicar sobre cabello húmedo, masajear suavemente y enjuagar',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/shampoo-pantene-pro-v-clasico'
    });
  }

  // Productos específicos según textura
  if (analysis.texture === 'rizado' || analysis.texture === 'crespo') {
    allRecommendations.push({
      id: 'pantene-rizos-definidos',
      name: 'Pantene Pro-V Rizos Definidos',
      type: 'tratamiento',
      description: 'Crema especializada que define y controla los rizos sin efecto crespo',
      benefits: ['Definición de rizos', 'Control anti-frizz', 'Hidratación duradera', 'Flexibilidad natural'],
      usage: 'Aplicar sobre cabello húmedo, distribuir uniformemente y dejar secar naturalmente',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/crema-pantene-pro-v-rizos-definidos'
    });
  }

  // Tratamientos específicos según preocupaciones  
  if (concerns.includes('caida')) {
    allRecommendations.push({
      id: 'pantene-fuerza-crecimiento',
      name: 'Pantene Pro-V Fuerza y Crecimiento',
      type: 'tratamiento',
      description: 'Tratamiento fortificante que reduce la caída y estimula el crecimiento saludable',
      benefits: ['Reduce caída hasta 90%', 'Estimula crecimiento', 'Fortalece desde la raíz', 'Mayor densidad'],
      usage: 'Aplicar en cuero cabelludo limpio, masajear suavemente, no enjuagar',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/tratamiento-pantene-pro-v-fuerza-y-crecimiento'
    });
  }

  if (concerns.includes('caspa')) {
    allRecommendations.push({
      id: 'pantene-anticaspa',
      name: 'Pantene Pro-V Anticaspa',
      type: 'shampoo',
      description: 'Fórmula especializada que elimina la caspa visible y previene su reaparición',
      benefits: ['Elimina caspa 100%', 'Previene reaparición', 'Alivia picazón', 'Cuero cabelludo saludable'],
      usage: 'Usar 2-3 veces por semana, masajear en cuero cabelludo y dejar actuar 2 minutos',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/shampoo-pantene-pro-v-anticaspa'
    });
  }

  if (concerns.includes('puntas') || treatments.includes('tinte') || treatments.includes('decoloracion')) {
    allRecommendations.push({
      id: 'pantene-reparacion-total',
      name: 'Pantene Pro-V Reparación Total',
      type: 'tratamiento',
      description: 'Tratamiento reparador intensivo para cabello dañado y con puntas abiertas',
      benefits: ['Repara daño extremo', 'Sella puntas abiertas', 'Fortalece fibra capilar', 'Protección duradera'],
      usage: 'Aplicar en cabello húmedo, concentrarse en medios y puntas, dejar actuar 5 minutos',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/tratamiento-pantene-pro-v-reparacion-total'
    });
  }

  if (concerns.includes('volumen')) {
    allRecommendations.push({
      id: 'pantene-volumen-cuerpo',
      name: 'Pantene Pro-V Volumen y Cuerpo',
      type: 'shampoo',
      description: 'Fórmula ligera que aporta volumen y cuerpo sin apelmazar',
      benefits: ['Volumen desde la raíz', 'Cuerpo natural', 'Textura ligera', 'Movimiento libre'],
      usage: 'Aplicar en cabello húmedo, masajear desde raíces y enjuagar completamente',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/shampoo-pantene-pro-v-volumen-y-cuerpo'
    });
  }

  // Siempre incluir un acondicionador complementario si no se ha añadido
  const hasConditioner = allRecommendations.some(r => r.type === 'acondicionador');
  if (!hasConditioner && analysis.type !== 'graso') {
    allRecommendations.push({
      id: 'pantene-acondicionador-clasico',
      name: 'Pantene Pro-V Acondicionador Clásico',
      type: 'acondicionador',
      description: 'Acondicionador nutritivo que complementa el cuidado diario del cabello',
      benefits: ['Nutrición profunda', 'Desenreda fácilmente', 'Suavidad duradera', 'Brillo natural'],
      usage: 'Aplicar en medios y puntas después del shampoo, dejar actuar 2-3 minutos',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/acondicionador-pantene-pro-v-clasico'
    });
  }

  // Seleccionar solo 3 productos: 1 shampoo, 1 acondicionador, 1 tratamiento
  const finalRecommendations: ProductRecommendation[] = [];
  
  // Buscar 1 shampoo
  const shampoo = allRecommendations.find(r => r.type === 'shampoo');
  if (shampoo) finalRecommendations.push(shampoo);
  
  // Buscar 1 acondicionador
  const conditioner = allRecommendations.find(r => r.type === 'acondicionador');
  if (conditioner) finalRecommendations.push(conditioner);
  
  // Buscar 1 tratamiento (mascarilla o tratamiento)
  const treatment = allRecommendations.find(r => r.type === 'tratamiento' || r.type === 'mascarilla');
  if (treatment) finalRecommendations.push(treatment);
  
  // Si no hay suficientes productos, completar con los disponibles
  while (finalRecommendations.length < 3 && finalRecommendations.length < allRecommendations.length) {
    const remaining = allRecommendations.find(r => !finalRecommendations.includes(r));
    if (remaining) finalRecommendations.push(remaining);
  }
  
  return finalRecommendations;
};

const generateCareRoutine = (analysis: HairAnalysis, answers: Record<string, any>): CareRoutine => {
  const washFrequency = answers['wash-frequency'];
  const concerns = answers['hair-concerns'] || [];
  
  const routine: CareRoutine = {
    morning: [
      'Cepillar suavemente con cepillo de cerdas naturales',
      'Aplicar protector térmico si usas herramientas de calor'
    ],
    evening: [
      'Cepillar el cabello para distribuir aceites naturales',
      'Aplicar serum o aceite en puntas si es necesario'
    ],
    weekly: [],
    monthly: [
      'Cortar puntas para mantener el cabello saludable',
      'Evaluar el estado del cabello y ajustar productos'
    ]
  };

  // Ajustar rutina según tipo de cabello
  if (analysis.type === 'graso') {
    routine.morning.push('Usar champú seco si es necesario');
    routine.weekly.push('Lavar el cabello según necesidad (puede ser diario)');
  } else if (analysis.type === 'seco') {
    routine.evening.push('Aplicar aceite nutritivo en puntas');
    routine.weekly.push('Aplicar mascarilla hidratante 1-2 veces');
  }

  // Ajustar según preocupaciones
  if (concerns.includes('caida')) {
    routine.evening.push('Masajear cuero cabelludo 5 minutos');
    routine.weekly.push('Aplicar tratamiento anticaída');
  }

  if (concerns.includes('caspa')) {
    routine.weekly.push('Usar shampoo anticaspa 2-3 veces');
  }

  // Ajustar según frecuencia de lavado
  if (washFrequency === 'diario') {
    routine.weekly.push('Lavar diariamente con shampoo suave');
  } else if (washFrequency === 'menos') {
    routine.weekly.push('Lavar 1-2 veces por semana máximo');
    routine.weekly.push('Usar shampoo seco entre lavados');
  }

  return routine;
};

const generateTips = (analysis: HairAnalysis, answers: Record<string, any>): string[] => {
  const tips: string[] = [
    'Usa agua tibia, no caliente, para lavar tu cabello',
    'Desenreda el cabello con un peine de dientes anchos cuando esté húmedo',
    'Protege tu cabello del sol con productos con filtro UV',
    'Duerme en fundas de almohada de seda o satén'
  ];

  // Tips específicos según tipo
  if (analysis.type === 'graso') {
    tips.push('Evita tocar el cabello con las manos durante el día');
    tips.push('Usa productos oil-free');
    tips.push('Enjuaga bien los productos para evitar residuos');
  } else if (analysis.type === 'seco') {
    tips.push('Limita el uso de herramientas de calor');
    tips.push('Aplica mascarillas hidratantes regularmente');
    tips.push('Evita productos con alcohol');
  }

  // Tips según textura
  if (analysis.texture === 'rizado' || analysis.texture === 'crespo') {
    tips.push('Usa productos específicos para cabello rizado');
    tips.push('Aplica productos con el cabello húmedo');
    tips.push('Evita cepillar el cabello seco');
  }

  // Tips según tratamientos químicos
  const treatments = answers['treatments'] || [];
  if (treatments.includes('tinte') || treatments.includes('decoloracion')) {
    tips.push('Usa productos para cabello teñido');
    tips.push('Aplica tratamientos reparadores regularmente');
    tips.push('Evita el exceso de calor');
  }

  return tips;
};