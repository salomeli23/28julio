/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        'pure-white': '#FFFFFF',
        'intense-black': '#000000',
        'bright-gold': '#CBA258',
        'soft-beige': '#F5EDE4',
      },
    },
  },
  plugins: [],
};
