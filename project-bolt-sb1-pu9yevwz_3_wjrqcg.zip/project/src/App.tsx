import React, { useState, useEffect } from 'react';
import SplashScreen from './components/SplashScreen';
import MainMenu from './components/MainMenu';
import CameraModule from './components/CameraModule';
import DiagnosisResults from './components/DiagnosisResults';
import Questionnaire from './components/Questionnaire';
import { DiagnosisData } from './types/diagnosis';

export type AppScreen = 'splash' | 'menu' | 'camera' | 'questionnaire' | 'results';

function App() {
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('splash');
  const [diagnosisData, setDiagnosisData] = useState<DiagnosisData | null>(null);

  const handleScreenChange = (screen: AppScreen) => {
    setCurrentScreen(screen);
  };

  const handleDiagnosisComplete = (data: DiagnosisData) => {
    setDiagnosisData(data);
    setCurrentScreen('results');
  };

  const handleRestart = () => {
    setDiagnosisData(null);
    setCurrentScreen('menu');
  };

  return (
    <div className="min-h-screen bg-pure-white overflow-hidden">
      {currentScreen === 'splash' && (
        <SplashScreen onComplete={() => handleScreenChange('menu')} />
      )}
      
      {currentScreen === 'menu' && (
        <MainMenu onNavigate={handleScreenChange} />
      )}
      
      {currentScreen === 'camera' && (
        <CameraModule 
          onComplete={handleDiagnosisComplete}
          onBack={() => handleScreenChange('menu')}
        />
      )}
      
      {currentScreen === 'questionnaire' && (
        <Questionnaire 
          onComplete={handleDiagnosisComplete}
          onBack={() => handleScreenChange('menu')}
        />
      )}
      
      {currentScreen === 'results' && diagnosisData && (
        <DiagnosisResults 
          data={diagnosisData}
          onRestart={handleRestart}
          onBack={() => handleScreenChange('menu')}
        />
      )}
    </div>
  );
}

export default App;