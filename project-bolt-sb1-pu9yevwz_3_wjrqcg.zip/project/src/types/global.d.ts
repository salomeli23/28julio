// Declaraciones de tipos globales para APIs del navegador

declare global {
  interface Window {
    FaceDetector: any;
  }
}

export {};