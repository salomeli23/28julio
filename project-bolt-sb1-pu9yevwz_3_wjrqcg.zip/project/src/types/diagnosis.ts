export interface CapturedImage {
  id: string;
  type: 'front' | 'side' | 'back' | 'scalp';
  url: string;
  timestamp: number;
}

export interface HairAnalysis {
  type: 'graso' | 'seco' | 'mixto' | 'normal';
  texture: 'liso' | 'ondulado' | 'rizado' | 'crespo';
  density: 'baja' | 'media' | 'alta';
  volume: 'bajo' | 'medio' | 'alto';
  condition: 'excelente' | 'bueno' | 'regular' | 'necesita_atencion';
}

export interface ProductRecommendation {
  id: string;
  name: string;
  type: 'shampoo' | 'acondicionador' | 'tratamiento' | 'mascarilla' | 'aceite';
  description: string;
  benefits: string[];
  usage: string;
  image?: string;
  link?: string;
}

export interface CareRoutine {
  morning: string[];
  evening: string[];
  weekly: string[];
  monthly: string[];
}

export interface DiagnosisData {
  images?: CapturedImage[];
  questionnaire?: Record<string, any>;
  analysis: HairAnalysis;
  recommendations: ProductRecommendation[];
  routine: CareRoutine;
  tips: string[];
  timestamp: number;
}