import React from 'react';
import { ArrowLeft, Share2, Star, Clock, CheckCircle, ShoppingCart } from 'lucide-react';
import { DiagnosisData } from '../types/diagnosis';

interface DiagnosisResultsProps {
  data: DiagnosisData;
  onRestart: () => void;
  onBack: () => void;
}

const DiagnosisResults: React.FC<DiagnosisResultsProps> = ({ data, onRestart, onBack }) => {
  const getHairTypeColor = (type: string) => {
    switch (type) {
      case 'graso': return 'bg-blue-500';
      case 'seco': return 'bg-orange-500';
      case 'mixto': return 'bg-yellow-500';
      case 'normal': return 'bg-green-500';
      default: return 'bg-gray-500';
    }
  };

  const getTextureIcon = (texture: string) => {
    switch (texture) {
      case 'liso': return '━';
      case 'ondulado': return '～';
      case 'rizado': return '〜';
      case 'crespo': return '≈';
      default: return '━';
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Mi Diagnóstico Capilar',
        text: `Mi tipo de cabello es ${data.analysis.type} con textura ${data.analysis.texture}`,
        url: window.location.href
      });
    }
  };

  const handleDownload = () => {
    const resultData = {
      diagnosis: data.analysis,
      recommendations: data.recommendations,
      routine: data.routine,
      tips: data.tips,
      timestamp: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(resultData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'diagnostico-capilar.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="h-screen overflow-y-auto bg-soft-beige">
      <div className="min-h-screen p-8">
        <div className="flex justify-between items-center mb-8">
          <button
            onClick={onBack}
            className="bg-intense-black bg-opacity-50 text-pure-white p-3 rounded-full hover:bg-opacity-70 transition-all"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          
          <div className="flex gap-4">
            <button
              onClick={handleShare}
              className="bg-bright-gold text-pure-white px-4 py-2 rounded-full hover:bg-bright-gold transition-all flex items-center gap-2"
            >
              <Share2 className="w-4 h-4" />
              Compartir
            </button>
          </div>
        </div>

        <div className="max-w-4xl mx-auto">
          {/* Título principal */}
          <div className="text-center mb-12">
            <h1 className="text-5xl font-bold text-intense-black mb-4">
              Tu Diagnóstico Capilar
            </h1>
            <p className="text-xl text-intense-black opacity-70">
              Análisis completo y recomendaciones personalizadas
            </p>
          </div>

          {/* Análisis principal */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
            <div className="bg-pure-white bg-opacity-90 backdrop-blur-sm rounded-2xl p-8">
              <h2 className="text-2xl font-bold text-intense-black mb-6">Análisis de tu Cabello</h2>
              
              <div className="space-y-6">
                <div>
                  <label className="text-bright-gold text-sm uppercase tracking-wider">Tipo de Cabello</label>
                  <div className="flex items-center gap-3 mt-2">
                    <div className={`w-4 h-4 rounded-full ${getHairTypeColor(data.analysis.type)}`}></div>
                    <span className="text-intense-black text-xl font-semibold capitalize">{data.analysis.type}</span>
                  </div>
                </div>

                <div>
                  <label className="text-bright-gold text-sm uppercase tracking-wider">Textura</label>
                  <div className="flex items-center gap-3 mt-2">
                    <span className="text-2xl">{getTextureIcon(data.analysis.texture)}</span>
                    <span className="text-intense-black text-xl font-semibold capitalize">{data.analysis.texture}</span>
                  </div>
                </div>

                <div>
                  <label className="text-bright-gold text-sm uppercase tracking-wider">Densidad</label>
                  <div className="flex items-center gap-3 mt-2">
                    <div className="flex gap-1">
                      {[1, 2, 3].map(i => (
                        <div 
                          key={i}
                          className={`w-3 h-3 rounded-full ${
                            i <= (data.analysis.density === 'alta' ? 3 : data.analysis.density === 'media' ? 2 : 1)
                              ? 'bg-bright-gold' 
                              : 'bg-soft-beige'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-intense-black text-xl font-semibold capitalize">{data.analysis.density}</span>
                  </div>
                </div>

                <div>
                  <label className="text-bright-gold text-sm uppercase tracking-wider">Condición General</label>
                  <div className="flex items-center gap-3 mt-2">
                    <Star className="w-5 h-5 text-bright-gold" />
                    <span className="text-intense-black text-xl font-semibold capitalize">
                      {data.analysis.condition.replace('_', ' ')}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-pure-white bg-opacity-90 backdrop-blur-sm rounded-2xl p-8">
              <h2 className="text-2xl font-bold text-intense-black mb-6">Productos Recomendados</h2>
              
              <div className="space-y-4">
                {data.recommendations.map((product, index) => (
                  <div key={product.id} className="bg-soft-beige bg-opacity-50 rounded-xl p-4">
                    <div className="flex items-start gap-4 mb-3">
                      {product.image ? (
                        <a 
                          href={product.link} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex-shrink-0"
                        >
                          <img 
                            src={product.image} 
                            alt={product.name}
                            className="w-16 h-16 rounded-lg object-cover hover:scale-105 transition-transform cursor-pointer"
                          />
                        </a>
                      ) : (
                        <div className="w-16 h-16 bg-gradient-to-r from-bright-gold to-bright-gold rounded-lg flex items-center justify-center text-pure-white font-bold flex-shrink-0">
                          <ShoppingCart className="w-6 h-6" />
                        </div>
                      )}
                      <div className="flex-1">
                        <h3 className="text-intense-black font-semibold text-lg">
                          {product.link ? (
                            <a 
                              href={product.link} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="hover:text-bright-gold transition-colors"
                            >
                              {product.name}
                            </a>
                          ) : (
                            product.name
                          )}
                        </h3>
                        <p className="text-bright-gold text-sm capitalize mb-1">{product.type}</p>
                        <p className="text-intense-black opacity-70 text-sm">{product.description}</p>
                      </div>
                    </div>
                    <div className="mt-4">
                      <p className="text-bright-gold text-xs font-semibold mb-1">Beneficios:</p>
                      <div className="flex flex-wrap gap-1">
                        {product.benefits.slice(0, 3).map((benefit, idx) => (
                          <span key={idx} className="bg-bright-gold bg-opacity-50 text-intense-black px-2 py-1 rounded-full text-xs">
                            {benefit}
                          </span>
                        ))}
                      </div>
                    </div>
                    <div className="mt-3">
                      <p className="text-bright-gold text-xs font-semibold mb-1">Modo de uso:</p>
                      <p className="text-intense-black opacity-70 text-xs">{product.usage}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Rutina de cuidado */}
          <div className="bg-pure-white bg-opacity-90 backdrop-blur-sm rounded-2xl p-8 mb-12">
            <h2 className="text-2xl font-bold text-intense-black mb-6">Tu Rutina de Cuidado</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {Object.entries(data.routine).map(([period, steps]) => (
                <div key={period} className="bg-soft-beige bg-opacity-50 rounded-xl p-6">
                  <div className="flex items-center gap-2 mb-4">
                    <Clock className="w-5 h-5 text-bright-gold" />
                    <h3 className="text-intense-black font-semibold capitalize">
                      {period === 'morning' ? 'Mañana' : 
                       period === 'evening' ? 'Noche' : 
                       period === 'weekly' ? 'Semanal' : 'Mensual'}
                    </h3>
                  </div>
                  <ul className="space-y-2">
                    {steps.map((step, index) => (
                      <li key={index} className="flex items-start gap-2 text-intense-black opacity-80 text-sm">
                        <CheckCircle className="w-4 h-4 text-bright-gold mt-0.5 flex-shrink-0" />
                        {step}
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>

          {/* Consejos adicionales */}
          <div className="bg-pure-white bg-opacity-90 backdrop-blur-sm rounded-2xl p-8 mb-12">
            <h2 className="text-2xl font-bold text-intense-black mb-6">Consejos Adicionales</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {data.tips.map((tip, index) => (
                <div key={index} className="bg-soft-beige bg-opacity-50 rounded-xl p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-6 h-6 bg-bright-gold rounded-full flex items-center justify-center text-pure-white font-bold text-sm">
                      {index + 1}
                    </div>
                    <p className="text-intense-black opacity-80">{tip}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Botón de nuevo diagnóstico */}
          <div className="text-center">
            <button
              onClick={onRestart}
              className="bg-gradient-to-r from-bright-gold to-bright-gold text-pure-white px-8 py-4 rounded-full text-xl font-semibold hover:scale-105 transition-all duration-300"
            >
              Realizar Nuevo Diagnóstico
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DiagnosisResults;