import React, { useEffect, useRef } from 'react';
import { Camera, FileText, Sparkles, Brain } from 'lucide-react';
import { AppScreen } from '../App';

interface MainMenuProps {
  onNavigate: (screen: AppScreen) => void;
}

const MainMenu: React.FC<MainMenuProps> = ({ onNavigate }) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    // Reproducir audio de bienvenida
    if (audioRef.current) {
      audioRef.current.play().catch(console.error);
    }
  }, []);

  const menuOptions = [
    {
      id: 'ai-diagnosis',
      title: 'Diagnóstico con IA',
      subtitle: 'Análisis fotográfico inteligente',
      icon: Camera,
      action: () => onNavigate('camera')
    },
    {
      id: 'questionnaire',
      title: 'Autodiagnóstico',
      subtitle: 'Cuestionario inteligente',
      icon: FileText,
      action: () => onNavigate('questionnaire')
    }
  ];

  return (
    <div className="h-screen flex flex-col justify-center items-center p-8 bg-soft-beige">
      <audio
        ref={audioRef}
        preload="auto"
        className="hidden"
      >
        <source 
          src="https://res.cloudinary.com/dewemwkqf/video/upload/v1752850036/ElevenLabs_2025-07-18T14_46_20_Azucena_Ortega__pvc_sp102_s98_sb96_se47_b_m2_eep7c3.mp3" 
          type="audio/mpeg" 
        />
      </audio>

      <div className="text-center mb-12">
        <div className="mb-6">
          <Sparkles className="w-24 h-24 text-bright-gold mx-auto mb-4 animate-pulse" />
        </div>
        <h1 className="text-5xl font-bold text-intense-black mb-4">
          Diagnóstico Capilar
        </h1>
        <p className="text-xl text-intense-black opacity-70 mb-8">
          Descubre el cuidado perfecto para tu cabello
        </p>
        <div className="flex items-center justify-center gap-2 text-soft-sky-blue">
          <Brain className="w-5 h-5" />
          <span className="text-lg">Tecnología de Inteligencia Artificial</span>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-8 max-w-2xl w-full">
        {menuOptions.map((option) => (
          <button
            key={option.id}
            onClick={option.action}
            className="bg-gradient-to-r from-bright-gold to-bright-gold p-8 rounded-2xl text-white hover:scale-105 transition-all duration-300 shadow-2xl group"
          >
            <div className="flex items-center gap-6">
              <div className="bg-white bg-opacity-20 p-4 rounded-full">
                <option.icon className="w-12 h-12" />
              </div>
              <div className="text-left">
                <h3 className="text-2xl font-bold mb-2">{option.title}</h3>
                <p className="text-lg opacity-90">{option.subtitle}</p>
              </div>
            </div>
          </button>
        ))}
      </div>

      <div className="mt-12 text-center">
        <p className="text-intense-black opacity-60 text-lg">
          Selecciona el método de diagnóstico que prefieras
        </p>
      </div>
    </div>
  );
};

export default MainMenu;