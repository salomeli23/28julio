import React, { useState, useEffect } from 'react';
import { Play, Loader2 } from 'lucide-react';

interface SplashScreenProps {
  onComplete: () => void;
}

const SplashScreen: React.FC<SplashScreenProps> = ({ onComplete }) => {
  const [videoLoaded, setVideoLoaded] = useState(false);
  const [videoEnded, setVideoEnded] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const audioRef = React.useRef<HTMLAudioElement>(null);
  const videoRef = React.useRef<HTMLVideoElement>(null);

  useEffect(() => {
    // Simular carga inicial
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 2000);

    return () => clearTimeout(timer);
  }, []);


  const handleVideoLoad = () => {
    setVideoLoaded(true);
    // Sincronizar audio con video cuando ambos estén cargados
    if (audioRef.current && videoRef.current) {
      // Reproducir audio al mismo tiempo que el video
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(console.error);
    }
  };

  const handleVideoPlay = () => {
    // Asegurar que el audio se reproduzca cuando el video comience
    if (audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().catch(console.error);
    }
  };

  const handleVideoEnd = () => {
    setVideoEnded(true);
    // Pausar audio cuando termine el video
    if (audioRef.current) {
      audioRef.current.pause();
    }
  };


  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-16 h-16 text-purple-300 animate-spin mx-auto mb-4" />
          <p className="text-white text-xl">Cargando aplicación...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen relative bg-black overflow-hidden">
      {!videoLoaded && (
        <div className="absolute inset-0 flex items-center justify-center bg-black z-10">
          <div className="text-center">
            <Loader2 className="w-12 h-12 text-purple-300 animate-spin mx-auto mb-4" />
            <p className="text-white">Cargando video...</p>
          </div>
        </div>
      )}

      {/* Audio de inicio */}
      <audio
        ref={audioRef}
        preload="auto"
        className="hidden"
      >
        <source 
          src="https://res.cloudinary.com/dewemwkqf/video/upload/v1752789196/0717_r8et4l.mp3" 
          type="audio/mpeg" 
        />
      </audio>

      <video
        ref={videoRef}
        className="w-full h-full object-cover"
        autoPlay
        muted
        playsInline
        onLoadedData={handleVideoLoad}
        onPlay={handleVideoPlay}
        onEnded={handleVideoEnd}
      >
        <source 
          src="https://res.cloudinary.com/dewemwkqf/video/upload/v1752784414/Frida.P.1.0.Tension_SR.TT.9x16_jkig3n.mp4" 
          type="video/mp4" 
        />
        <p className="text-white text-center">Tu navegador no soporta la reproducción de video.</p>
      </video>

      {videoEnded && (
        <div className="absolute inset-0 bg-soft-beige bg-opacity-90 flex flex-col justify-end pb-32">
          <div className="text-center px-8">
            <h1 className="text-5xl font-bold text-intense-black mb-12">
              Diagnóstico Capilar IA
            </h1>
            <button
              onClick={onComplete}
              className="bg-gradient-to-r from-bright-gold to-bright-gold text-pure-white px-16 py-6 rounded-full text-2xl font-semibold hover:scale-105 transition-transform duration-300 flex items-center gap-4 mx-auto shadow-2xl"
            >
              <Play className="w-8 h-8" />
              Comenzar Diagnóstico
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default SplashScreen;