import React, { useState, useRef, useEffect } from 'react';
import { Camera, RotateCcw, CheckCircle, ArrowLeft, User, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { DiagnosisData, CapturedImage } from '../types/diagnosis';
import { analyzeImages } from '../utils/imageAnalysis';

interface CameraModuleProps {
  onComplete: (data: DiagnosisData) => void;
  onBack: () => void;
}

const photoSteps = [
  {
    id: 'front',
    title: 'Vista Frontal',
    description: 'Colócate frente a la cámara mostrando tu rostro y cabello completo',
    instruction: 'Mira directamente a la cámara con el cabello visible',
    positionGuide: 'Centra tu rostro en la pantalla y mantente quieto'
  },
  {
    id: 'side',
    title: 'Vista Lateral',
    description: 'Gira tu cabeza hacia la derecha mostrando el perfil',
    instruction: 'Muestra el perfil derecho de tu cabello',
    positionGuide: 'Gira completamente hacia la derecha y mantén la posición'
  },
  {
    id: 'back',
    title: 'Vista Posterior',
    description: 'Da la espalda a la cámara mostrando la nuca y largo del cabello',
    instruction: 'Muestra la parte posterior de tu cabello',
    positionGuide: 'Gira completamente de espaldas a la cámara'
  },
  {
    id: 'scalp',
    title: 'Cuero Cabelludo',
    description: 'Inclina la cabeza hacia abajo para mostrar las raíces y cuero cabelludo',
    instruction: 'Enfoca las raíces y el cuero cabelludo',
    positionGuide: 'Inclina la cabeza hacia abajo para mostrar la coronilla'
  }
];

const CameraModule: React.FC<CameraModuleProps> = ({ onComplete, onBack }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [capturedImages, setCapturedImages] = useState<CapturedImage[]>([]);
  const [isCapturing, setIsCapturing] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const [personDetected, setPersonDetected] = useState(false);
  const [positionCorrect, setPositionCorrect] = useState(false);
  const [faceDetector, setFaceDetector] = useState<any>(null);
  const [detectionInterval, setDetectionInterval] = useState<NodeJS.Timeout | null>(null);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [detectionError, setDetectionError] = useState<string | null>(null);
  const [autoCapture, setAutoCapture] = useState(true);
  const [positionStableTime, setPositionStableTime] = useState(0);
  const [lastPositionCheck, setLastPositionCheck] = useState(Date.now());
  const [instructionSpoken, setInstructionSpoken] = useState(false);
  
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const detectionCanvasRef = useRef<HTMLCanvasElement>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  useEffect(() => {
    startCamera();
    initializeFaceDetection();
    return () => {
      stopCamera();
      stopDetection();
    };
  }, []);

  useEffect(() => {
    // Dar instrucciones cuando cambia el paso
    if (!instructionSpoken) {
      setTimeout(() => {
        speakInstruction(`Paso ${currentStep + 1}: ${photoSteps[currentStep].instruction}. ${photoSteps[currentStep].positionGuide}`);
        setInstructionSpoken(true);
      }, 1000);
    }
  }, [currentStep, instructionSpoken]);

  useEffect(() => {
    // Auto captura cuando la posición es correcta por 2 segundos
    if (autoCapture && positionCorrect && personDetected && !isCapturing) {
      const now = Date.now();
      if (now - lastPositionCheck >= 2000) { // 2 segundos en posición correcta
        startAutomaticCapture();
      }
    } else {
      setPositionStableTime(0);
    }
  }, [positionCorrect, personDetected, autoCapture, isCapturing, lastPositionCheck]);

  const initializeFaceDetection = async () => {
    try {
      if ('FaceDetector' in window) {
        const detector = new (window as any).FaceDetector({
          maxDetectedFaces: 5,
          fastMode: false
        });
        setFaceDetector(detector);
        startPersonDetection();
      } else {
        console.log('Face Detection API no disponible, usando detección alternativa');
        startAlternativeDetection();
      }
    } catch (error) {
      console.error('Error inicializando detección facial:', error);
      setDetectionError('Error en la detección facial');
      startAlternativeDetection();
    }
  };

  const startPersonDetection = () => {
    if (detectionInterval) clearInterval(detectionInterval);
    
    const interval = setInterval(async () => {
      await detectPerson();
    }, 500); // Más frecuente para mejor respuesta
    
    setDetectionInterval(interval);
  };

  const startAlternativeDetection = () => {
    if (detectionInterval) clearInterval(detectionInterval);
    
    const interval = setInterval(() => {
      detectPersonAlternative();
    }, 500);
    
    setDetectionInterval(interval);
  };

  const detectPerson = async () => {
    if (!videoRef.current || !detectionCanvasRef.current || !faceDetector) return;

    try {
      const video = videoRef.current;
      const canvas = detectionCanvasRef.current;
      const ctx = canvas.getContext('2d');
      
      if (!ctx || video.videoWidth === 0 || video.videoHeight === 0) return;

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0);

      const faces = await faceDetector.detect(canvas);
      
      if (faces && faces.length > 0) {
        setPersonDetected(true);
        setDetectionError(null);
        
        const positionValidation = validatePersonPosition(faces[0]);
        setPositionCorrect(positionValidation.isValid);
        
        if (positionValidation.isValid) {
          setLastPositionCheck(Date.now());
        }
        
      } else {
        setPersonDetected(false);
        setPositionCorrect(false);
      }
    } catch (error) {
      console.error('Error en detección facial:', error);
      setPersonDetected(false);
      setPositionCorrect(false);
    }
  };

  const detectPersonAlternative = () => {
    if (!videoRef.current || !detectionCanvasRef.current) return;

    try {
      const video = videoRef.current;
      const canvas = detectionCanvasRef.current;
      const ctx = canvas.getContext('2d');
      
      if (!ctx || video.videoWidth === 0 || video.videoHeight === 0) return;

      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      ctx.drawImage(video, 0, 0);

      const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const hasMovement = analyzeImageForMovement(imageData);
      
      setPersonDetected(hasMovement);
      // Para detección alternativa, asumimos posición correcta si hay movimiento
      setPositionCorrect(hasMovement);
      
      if (hasMovement) {
        setLastPositionCheck(Date.now());
      }
    } catch (error) {
      console.error('Error en detección alternativa:', error);
      setPersonDetected(false);
      setPositionCorrect(false);
    }
  };

  const analyzeImageForMovement = (imageData: ImageData): boolean => {
    const data = imageData.data;
    let totalBrightness = 0;
    let pixelCount = 0;
    let variationCount = 0;
    
    for (let i = 0; i < data.length; i += 4) {
      const r = data[i];
      const g = data[i + 1];
      const b = data[i + 2];
      const brightness = (r + g + b) / 3;
      totalBrightness += brightness;
      pixelCount++;
      
      // Contar variaciones significativas de color
      if (Math.abs(r - g) > 30 || Math.abs(g - b) > 30 || Math.abs(r - b) > 30) {
        variationCount++;
      }
    }
    
    const avgBrightness = totalBrightness / pixelCount;
    const variationRatio = variationCount / pixelCount;
    
    return avgBrightness > 30 && avgBrightness < 200 && variationRatio > 0.1;
  };

  const validatePersonPosition = (face: any): { isValid: boolean; message: string } => {
    const step = photoSteps[currentStep];
    const faceBox = face.boundingBox;
    const centerX = faceBox.x + faceBox.width / 2;
    const centerY = faceBox.y + faceBox.height / 2;
    
    switch (step.id) {
      case 'front':
        // Vista frontal: rostro centrado y de tamaño adecuado
        if (centerX < 0.3 || centerX > 0.7) {
          return { isValid: false, message: 'Centra tu rostro en la pantalla' };
        }
        if (faceBox.width < 0.15) {
          return { isValid: false, message: 'Acércate más a la cámara' };
        }
        if (faceBox.width > 0.4) {
          return { isValid: false, message: 'Aléjate un poco de la cámara' };
        }
        return { isValid: true, message: 'Posición perfecta para vista frontal' };

      case 'side':
        // Vista lateral: rostro hacia un lado
        if (centerX > 0.3 && centerX < 0.7) {
          return { isValid: false, message: 'Gira más hacia el lado derecho' };
        }
        if (faceBox.width < 0.1) {
          return { isValid: false, message: 'Acércate más a la cámara' };
        }
        return { isValid: true, message: 'Perfecto para vista lateral' };

      case 'back':
        // Vista posterior: detección mínima de rostro
        if (faceBox.width > 0.15) {
          return { isValid: false, message: 'Gira completamente de espaldas' };
        }
        return { isValid: true, message: 'Excelente vista posterior' };

      case 'scalp':
        // Cuero cabelludo: rostro en parte superior o no visible
        if (centerY > 0.6) {
          return { isValid: false, message: 'Inclina más la cabeza hacia abajo' };
        }
        return { isValid: true, message: 'Perfecto para mostrar cuero cabelludo' };

      default:
        return { isValid: true, message: 'Posición aceptable' };
    }
  };

  const stopDetection = () => {
    if (detectionInterval) {
      clearInterval(detectionInterval);
      setDetectionInterval(null);
    }
  };

  const startCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          width: { ideal: 1080 },
          height: { ideal: 1920 },
          facingMode: 'user'
        }
      });
      
      setCameraStream(stream);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (error) {
      console.error('Error accessing camera:', error);
    }
  };

  const stopCamera = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach(track => track.stop());
    }
  };

  const speakInstruction = (text: string) => {
    if ('speechSynthesis' in window) {
      speechSynthesis.cancel(); // Cancelar cualquier síntesis anterior
      
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'es-CO';
      utterance.rate = 0.8;
      utterance.pitch = 1.1;
      
      // Buscar voz femenina en español
      const voices = speechSynthesis.getVoices();
      const femaleVoice = voices.find(voice => 
        voice.lang.includes('es') && 
        (voice.name.toLowerCase().includes('female') || 
         voice.name.toLowerCase().includes('mujer') ||
         voice.name.toLowerCase().includes('maria'))
      );
      
      if (femaleVoice) {
        utterance.voice = femaleVoice;
      }
      
      speechSynthesis.speak(utterance);
    }
  };

  const startAutomaticCapture = () => {
    if (isCapturing) return;
    
    setIsCapturing(true);
    speakInstruction('Perfecto! Mantén la posición. Capturando en 3, 2, 1');
    
    let count = 3;
    setCountdown(count);
    
    const timer = setInterval(() => {
      count--;
      setCountdown(count);
      
      if (count === 0) {
        clearInterval(timer);
        capturePhoto();
      }
    }, 1000);
  };

  const capturePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const canvas = canvasRef.current;
      const video = videoRef.current;
      
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0);
        
        canvas.toBlob((blob) => {
          if (blob) {
            const url = URL.createObjectURL(blob);
            const newImage: CapturedImage = {
              id: Date.now().toString(),
              type: photoSteps[currentStep].id as any,
              url,
              timestamp: Date.now()
            };
            
            setCapturedImages(prev => [...prev, newImage]);
            setIsCapturing(false);
            setCountdown(0);
            setPositionCorrect(false);
            setInstructionSpoken(false);
            
            speakInstruction('¡Foto capturada correctamente!');
            
            if (currentStep < photoSteps.length - 1) {
              setTimeout(() => {
                setCurrentStep(currentStep + 1);
              }, 2000);
            } else {
              setTimeout(() => {
                processImages();
              }, 2000);
            }
          }
        }, 'image/jpeg', 0.8);
      }
    }
  };

  const processImages = async () => {
    setIsProcessing(true);
    speakInstruction('Excelente! Todas las fotos han sido capturadas. Ahora procesaré las imágenes para generar tu diagnóstico personalizado. Esto tomará unos momentos.');
    
    await new Promise(resolve => setTimeout(resolve, 10000));
    
    const diagnosis = analyzeImages(capturedImages);
    onComplete(diagnosis);
  };

  const retakePhoto = () => {
    const lastImage = capturedImages[capturedImages.length - 1];
    if (lastImage) {
      URL.revokeObjectURL(lastImage.url);
      setCapturedImages(prev => prev.slice(0, -1));
      if (currentStep > 0) {
        setCurrentStep(currentStep - 1);
        setInstructionSpoken(false);
      }
      speakInstruction('Foto eliminada. Vamos a repetir esta toma');
    }
  };

  const manualCapture = () => {
    if (!personDetected) {
      speakInstruction('Por favor, colócate frente a la cámara para que pueda detectarte');
      return;
    }
    startAutomaticCapture();
  };

  const currentPhotoStep = photoSteps[currentStep];
  const progressPercentage = ((currentStep + capturedImages.length) / (photoSteps.length * 2)) * 100;

  if (isProcessing) {
    return (
      <div className="h-screen relative overflow-hidden bg-black">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover opacity-30"
        >
          <source 
            src="https://res.cloudinary.com/dewemwkqf/video/upload/v1753053530/20250719_1856_Animated_Expressions_remix_01k0jhvdete0vb3ybaccwedf5c_uodh4d.mp4" 
            type="video/mp4" 
          />
        </video>
        
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        
        <div className="relative z-10 h-full flex items-center justify-center">
          <div className="text-center text-pure-white">
            <div className="animate-spin rounded-full h-32 w-32 border-b-4 border-bright-gold mx-auto mb-8"></div>
            <h2 className="text-4xl font-bold mb-4 text-pure-white">Procesando Imágenes</h2>
            <p className="text-xl text-pure-white opacity-90">Generando tu diagnóstico personalizado...</p>
            <div className="mt-8 flex justify-center">
              <div className="flex space-x-2">
                <div className="w-3 h-3 bg-bright-gold rounded-full animate-bounce"></div>
                <div className="w-3 h-3 bg-bright-gold rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                <div className="w-3 h-3 bg-bright-gold rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen relative bg-black overflow-hidden">
      <button
        onClick={onBack}
        className="absolute top-4 left-4 z-20 bg-black bg-opacity-50 text-white p-3 rounded-full hover:bg-opacity-70 transition-all"
      >
        <ArrowLeft className="w-6 h-6" />
      </button>

      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        className="absolute inset-0 w-full h-full object-cover"
      />

      <canvas ref={canvasRef} className="hidden" />
      <canvas ref={detectionCanvasRef} className="hidden" />

      {/* Overlay de información */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black">
        
        {/* Información del paso actual */}
        <div className="absolute top-20 left-0 right-0 text-center text-white px-8">
          <div className="bg-soft-beige bg-opacity-95 rounded-2xl p-6 max-w-2xl mx-auto">
            <h2 className="text-3xl font-bold text-intense-black mb-2">
              {currentPhotoStep.title} ({currentStep + 1}/4)
            </h2>
            <p className="text-xl text-intense-black opacity-80 mb-4">{currentPhotoStep.description}</p>
            
            {/* Estado de detección */}
            <div className="flex items-center justify-center gap-4 mb-4">
              <div className="flex items-center gap-2">
                {personDetected ? (
                  <>
                    <Eye className="w-6 h-6 text-green-600" />
                    <span className="text-green-600 font-semibold">✓ Persona detectada</span>
                  </>
                ) : (
                  <>
                    <EyeOff className="w-6 h-6 text-red-600" />
                    <span className="text-red-600 font-semibold">⚠ Colócate frente a la cámara</span>
                  </>
                )}
              </div>
              
              <div className="flex items-center gap-2">
                {positionCorrect ? (
                  <>
                    <CheckCircle className="w-6 h-6 text-green-600" />
                    <span className="text-green-600 font-semibold">✓ Posición correcta</span>
                  </>
                ) : (
                  <>
                    <AlertCircle className="w-6 h-6 text-yellow-600" />
                    <span className="text-yellow-600 font-semibold">⚠ Ajusta tu posición</span>
                  </>
                )}
              </div>
            </div>

            {/* Guía de posición */}
            <div className="bg-bright-gold bg-opacity-20 rounded-xl p-4">
              <p className="text-intense-black font-semibold text-lg">
                📍 {currentPhotoStep.positionGuide}
              </p>
              {positionCorrect && personDetected && !isCapturing && (
                <p className="text-green-600 font-bold mt-2 animate-pulse">
                  🎯 ¡Perfecto! Mantén esta posición...
                </p>
              )}
            </div>

            {detectionError && (
              <p className="text-bright-gold text-sm mt-2">
                {detectionError} - Usando detección alternativa
              </p>
            )}
          </div>
        </div>

        {/* Countdown grande */}
        {countdown > 0 && (
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-9xl font-bold text-white animate-pulse bg-black bg-opacity-50 rounded-full w-48 h-48 flex items-center justify-center">
              {countdown}
            </div>
          </div>
        )}

        {/* Controles inferiores */}
        <div className="absolute bottom-8 left-0 right-0 flex justify-center items-center gap-6">
          {!isCapturing ? (
            <>
              {/* Botón de captura manual (backup) */}
              <button
                onClick={manualCapture}
                disabled={!personDetected}
                className={`p-4 rounded-full text-white transition-all duration-300 ${
                  !personDetected 
                    ? 'bg-gray-600 opacity-50 cursor-not-allowed' 
                    : 'bg-red-600 hover:bg-red-700 hover:scale-110 shadow-lg'
                }`}
                title="Captura manual (backup)"
              >
                <Camera className="w-8 h-8" />
              </button>
              
              {/* Estado de auto-captura */}
              <div className="bg-black bg-opacity-70 px-6 py-3 rounded-full">
                <span className="text-white text-lg font-semibold">
                  {autoCapture ? (
                    positionCorrect && personDetected ? 
                      '🎯 Captura automática activada' : 
                      '⏳ Esperando posición correcta...'
                  ) : (
                    'Modo manual activado'
                  )}
                </span>
              </div>
              
              {/* Botón de repetir foto */}
              {capturedImages.length > 0 && (
                <button
                  onClick={retakePhoto}
                  className="bg-yellow-600 p-4 rounded-full text-white hover:bg-yellow-700 transition-all"
                  title="Repetir última foto"
                >
                  <RotateCcw className="w-6 h-6" />
                </button>
              )}
            </>
          ) : (
            <div className="bg-black bg-opacity-70 px-8 py-4 rounded-full">
              <span className="text-white text-xl">📸 Capturando en {countdown}...</span>
            </div>
          )}
        </div>

        {/* Indicadores de estado */}
        <div className="absolute top-4 right-4 z-20 flex flex-col gap-2">
          {/* Indicador de detección */}
          <div className={`w-4 h-4 rounded-full ${
            personDetected ? 'bg-green-400 animate-pulse' : 'bg-red-400'
          }`} title={personDetected ? 'Persona detectada' : 'Sin detección'}></div>
          
          {/* Indicador de posición */}
          <div className={`w-4 h-4 rounded-full ${
            positionCorrect ? 'bg-blue-400 animate-pulse' : 'bg-yellow-400'
          }`} title={positionCorrect ? 'Posición correcta' : 'Ajustar posición'}></div>
        </div>

        {/* Barra de progreso */}
        <div className="absolute bottom-32 left-0 right-0 px-8">
          <div className="bg-black bg-opacity-50 rounded-full p-2 max-w-md mx-auto">
            <div className="flex gap-2 justify-center mb-2">
              {photoSteps.map((_, index) => (
                <div
                  key={index}
                  className={`w-4 h-4 rounded-full transition-all ${
                    index < capturedImages.length
                      ? 'bg-green-500'
                      : index === currentStep
                      ? positionCorrect && personDetected
                        ? 'bg-blue-500 animate-pulse'
                        : 'bg-yellow-500'
                      : 'bg-gray-500'
                  }`}
                />
              ))}
            </div>
            <div className="text-center text-white text-sm">
              {capturedImages.length}/{photoSteps.length} fotos completadas
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CameraModule;