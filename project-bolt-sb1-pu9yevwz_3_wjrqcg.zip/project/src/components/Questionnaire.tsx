import React, { useState } from 'react';
import { ArrowLeft, ArrowRight, CheckCircle } from 'lucide-react';
import { DiagnosisData } from '../types/diagnosis';
import { analyzeQuestionnaire } from '../utils/questionnaireAnalysis';

interface QuestionnaireProps {
  onComplete: (data: DiagnosisData) => void;
  onBack: () => void;
}

const questions = [
  {
    id: 'hair-type',
    title: '¿Cómo describirías tu tipo de cabello?',
    options: [
      { value: 'graso', label: 'Graso - Se ve brillante y oleoso rápidamente' },
      { value: 'seco', label: 'Seco - Se ve opaco y se siente áspero' },
      { value: 'mixto', label: 'Mixto - Graso en raíces, seco en puntas' },
      { value: 'normal', label: 'Normal - Equilibrado, ni muy graso ni muy seco' }
    ]
  },
  {
    id: 'hair-texture',
    title: '¿Cuál es la textura natural de tu cabello?',
    options: [
      { value: 'liso', label: 'Liso - Sin ondas ni rizos' },
      { value: 'ondulado', label: 'Ondulado - Con ondas suaves' },
      { value: 'rizado', label: 'Rizado - Con rizos definidos' },
      { value: 'crespo', label: 'Crespo - Muy rizado y voluminoso' }
    ]
  },
  {
    id: 'hair-density',
    title: '¿Cómo es la densidad de tu cabello?',
    options: [
      { value: 'baja', label: 'Baja - Poco cabello, se ve el cuero cabelludo' },
      { value: 'media', label: 'Media - Cantidad normal de cabello' },
      { value: 'alta', label: 'Alta - Mucho cabello, muy espeso' }
    ]
  },
  {
    id: 'scalp-condition',
    title: '¿Cómo está tu cuero cabelludo?',
    options: [
      { value: 'normal', label: 'Normal - Sin problemas aparentes' },
      { value: 'caspa', label: 'Con caspa - Descamación visible' },
      { value: 'sensible', label: 'Sensible - Se irrita fácilmente' },
      { value: 'graso', label: 'Graso - Se ensucia rápidamente' }
    ]
  },
  {
    id: 'hair-concerns',
    title: '¿Cuáles son tus principales preocupaciones?',
    options: [
      { value: 'caida', label: 'Caída del cabello' },
      { value: 'caspa', label: 'Caspa o descamación' },
      { value: 'sequedad', label: 'Sequedad y falta de brillo' },
      { value: 'grasa', label: 'Exceso de grasa' },
      { value: 'puntas', label: 'Puntas abiertas' },
      { value: 'volumen', label: 'Falta de volumen' }
    ],
    multiple: true
  },
  {
    id: 'wash-frequency',
    title: '¿Con qué frecuencia lavas tu cabello?',
    options: [
      { value: 'diario', label: 'Diariamente' },
      { value: 'inter-diario', label: 'Cada dos días' },
      { value: 'semanal', label: '2-3 veces por semana' },
      { value: 'menos', label: 'Menos de 2 veces por semana' }
    ]
  },
  {
    id: 'treatments',
    title: '¿Qué tratamientos químicos has usado recientemente?',
    options: [
      { value: 'ninguno', label: 'Ninguno' },
      { value: 'tinte', label: 'Tinte o coloración' },
      { value: 'decoloracion', label: 'Decoloración' },
      { value: 'alisado', label: 'Alisado químico' },
      { value: 'permanente', label: 'Permanente' }
    ],
    multiple: true
  }
];

const Questionnaire: React.FC<QuestionnaireProps> = ({ onComplete, onBack }) => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [isProcessing, setIsProcessing] = useState(false);

  const speakText = (text: string) => {
    if ('speechSynthesis' in window) {
      // Cancelar cualquier síntesis en curso
      speechSynthesis.cancel();
      
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = 'es-CO'; // Español colombiano
      utterance.rate = 0.8;
      utterance.pitch = 1.2; // Tono más alto para voz femenina
      
      // Intentar usar una voz femenina colombiana
      const voices = speechSynthesis.getVoices();
      const femaleVoice = voices.find(voice => 
        (voice.lang.includes('es-CO') || voice.lang.includes('es')) && 
        (voice.name.toLowerCase().includes('female') || 
         voice.name.toLowerCase().includes('mujer') ||
         voice.name.toLowerCase().includes('maria') ||
         voice.name.toLowerCase().includes('carmen') ||
         voice.name.toLowerCase().includes('colombia') ||
         voice.name.toLowerCase().includes('bogota'))
      );
      
      if (femaleVoice) {
        utterance.voice = femaleVoice;
      } else {
        // Fallback: buscar cualquier voz en español
        const spanishVoice = voices.find(voice => voice.lang.includes('es'));
        if (spanishVoice) {
          utterance.voice = spanishVoice;
        }
      }
      
      speechSynthesis.speak(utterance);
    }
  };

  // Reproducir pregunta cuando cambia
  React.useEffect(() => {
    const question = questions[currentQuestion];
    speakText(question.title);
  }, [currentQuestion]);
  const handleAnswer = (questionId: string, value: string, isMultiple: boolean = false) => {
    // Reproducir la respuesta seleccionada
    const selectedOption = questions[currentQuestion].options.find(opt => opt.value === value);
    if (selectedOption) {
      speakText(`Has elegido: ${selectedOption.label}`);
    }
    
    setAnswers(prev => {
      if (isMultiple) {
        const currentAnswers = prev[questionId] || [];
        const newAnswers = currentAnswers.includes(value)
          ? currentAnswers.filter((v: string) => v !== value)
          : [...currentAnswers, value];
        return { ...prev, [questionId]: newAnswers };
      } else {
        return { ...prev, [questionId]: value };
      }
    });
  };

  const canProceed = () => {
    const question = questions[currentQuestion];
    const answer = answers[question.id];
    
    if (question.multiple) {
      return answer && answer.length > 0;
    } else {
      return answer !== undefined;
    }
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      speakText('Vamos a la siguiente pregunta');
      setCurrentQuestion(currentQuestion + 1);
    } else {
      speakText('Ahora voy a procesar todas tus respuestas para crear tu diagnóstico personalizado');
      processQuestionnaire();
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      speakText('Vamos a la pregunta anterior');
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const processQuestionnaire = async () => {
    setIsProcessing(true);
    
    // Simular procesamiento de 10 segundos
    await new Promise(resolve => setTimeout(resolve, 10000));
    
    const diagnosis = analyzeQuestionnaire(answers);
    onComplete(diagnosis);
  };

  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  if (isProcessing) {
    return (
      <div className="h-screen relative overflow-hidden bg-black">
        {/* Video de fondo */}
        <video
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover opacity-30"
        >
          <source 
            src="https://res.cloudinary.com/dewemwkqf/video/upload/v1753053530/20250719_1856_Animated_Expressions_remix_01k0jhvdete0vb3ybaccwedf5c_uodh4d.mp4" 
            type="video/mp4" 
          />
        </video>
        
        {/* Overlay oscuro */}
        <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        
        {/* Contenido */}
        <div className="relative z-10 h-full flex items-center justify-center">
          <div className="text-center text-pure-white">
            <div className="animate-spin rounded-full h-32 w-32 border-b-4 border-bright-gold mx-auto mb-8"></div>
            <h2 className="text-4xl font-bold mb-4 text-pure-white">Procesando Respuestas</h2>
            <p className="text-xl text-pure-white opacity-90">Generando tu diagnóstico personalizado...</p>
            <div className="mt-8 flex justify-center">
              <div className="flex space-x-2">
                <div className="w-3 h-3 bg-bright-gold rounded-full animate-bounce"></div>
                <div className="w-3 h-3 bg-bright-gold rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
                <div className="w-3 h-3 bg-bright-gold rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="h-screen flex flex-col p-8 bg-soft-beige">
      <button
        onClick={onBack}
        className="self-start mb-8 bg-intense-black bg-opacity-50 text-pure-white p-3 rounded-full hover:bg-opacity-70 transition-all"
      >
        <ArrowLeft className="w-6 h-6" />
      </button>

      {/* Barra de progreso */}
      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <span className="text-intense-black text-lg">
            Pregunta {currentQuestion + 1} de {questions.length}
          </span>
          <span className="text-bright-gold">{Math.round(progress)}%</span>
        </div>
        <div className="w-full bg-pure-white rounded-full h-2">
          <div 
            className="bg-gradient-to-r from-bright-gold to-bright-gold h-2 rounded-full transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      </div>

      {/* Pregunta actual */}
      <div className="flex-1 flex items-center justify-center">
        <div className="max-w-4xl w-full">
          <h2 className="text-4xl font-bold text-intense-black mb-12 text-center">
            {question.title}
          </h2>

          <div className="grid grid-cols-1 gap-4 max-w-2xl mx-auto">
            {question.options.map((option) => {
              const isSelected = question.multiple 
                ? (answers[question.id] || []).includes(option.value)
                : answers[question.id] === option.value;

              return (
                <button
                  key={option.value}
                  onClick={() => handleAnswer(question.id, option.value, question.multiple)}
                  className={`p-6 rounded-xl text-left transition-all duration-300 hover:scale-105 ${
                    isSelected
                      ? 'bg-gradient-to-r from-bright-gold to-bright-gold text-pure-white'
                      : 'bg-pure-white bg-opacity-80 text-intense-black hover:bg-opacity-100'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    {isSelected && <CheckCircle className="w-6 h-6" />}
                    <span className="text-lg">{option.label}</span>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Controles de navegación */}
      <div className="flex justify-between items-center mt-8">
        <button
          onClick={handlePrevious}
          disabled={currentQuestion === 0}
          className={`flex items-center gap-2 px-6 py-3 rounded-full transition-all ${
            currentQuestion === 0
              ? 'bg-pure-white text-intense-black opacity-50 cursor-not-allowed'
              : 'bg-bright-gold text-pure-white hover:bg-bright-gold'
          }`}
        >
          <ArrowLeft className="w-5 h-5" />
          Anterior
        </button>

        <button
          onClick={handleNext}
          disabled={!canProceed()}
          className={`flex items-center gap-2 px-6 py-3 rounded-full transition-all ${
            !canProceed()
              ? 'bg-pure-white text-intense-black opacity-50 cursor-not-allowed'
              : 'bg-gradient-to-r from-bright-gold to-bright-gold text-pure-white hover:scale-105'
          }`}
        >
          {currentQuestion === questions.length - 1 ? 'Finalizar' : 'Siguiente'}
          <ArrowRight className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default Questionnaire;