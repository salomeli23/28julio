import { CapturedImage, DiagnosisData, HairAnalysis, ProductRecommendation, CareRoutine } from '../types/diagnosis';

export const analyzeImages = (images: CapturedImage[]): DiagnosisData => {
  // Simulación de análisis de imagen con IA
  // En una implementación real, aquí se enviarían las imágenes a un servicio de IA
  
  const mockAnalysis: HairAnalysis = {
    type: getRandomHairType(),
    texture: getRandomTexture(),
    density: getRandomDensity(),
    volume: getRandomVolume(),
    condition: getRandomCondition()
  };

  const recommendations = generateRecommendations(mockAnalysis);
  const routine = generateCareRoutine(mockAnalysis);
  const tips = generateTips(mockAnalysis);

  return {
    images,
    analysis: mockAnalysis,
    recommendations,
    routine,
    tips,
    timestamp: Date.now()
  };
};

const getRandomHairType = (): 'graso' | 'seco' | 'mixto' | 'normal' => {
  const types = ['graso', 'seco', 'mixto', 'normal'] as const;
  return types[Math.floor(Math.random() * types.length)];
};

const getRandomTexture = (): 'liso' | 'ondulado' | 'rizado' | 'crespo' => {
  const textures = ['liso', 'ondulado', 'rizado', 'crespo'] as const;
  return textures[Math.floor(Math.random() * textures.length)];
};

const getRandomDensity = (): 'baja' | 'media' | 'alta' => {
  const densities = ['baja', 'media', 'alta'] as const;
  return densities[Math.floor(Math.random() * densities.length)];
};

const getRandomVolume = (): 'bajo' | 'medio' | 'alto' => {
  const volumes = ['bajo', 'medio', 'alto'] as const;
  return volumes[Math.floor(Math.random() * volumes.length)];
};

const getRandomCondition = (): 'excelente' | 'bueno' | 'regular' | 'necesita_atencion' => {
  const conditions = ['excelente', 'bueno', 'regular', 'necesita_atencion'] as const;
  return conditions[Math.floor(Math.random() * conditions.length)];
};

const generateRecommendations = (analysis: HairAnalysis): ProductRecommendation[] => {
  const allRecommendations: ProductRecommendation[] = [];

  // Productos Pantene según análisis de imagen
  if (analysis.type === 'graso') {
    allRecommendations.push({
      id: 'pantene-control-grasa-ia',
      name: 'Pantene Pro-V Control de Grasa',
      type: 'shampoo',
      description: 'Detectamos exceso de grasa. Este shampoo especializado limpia profundamente y controla el sebo',
      benefits: ['Control de grasa hasta 72h', 'Limpieza profunda', 'Cabello ligero', 'Fórmula balanceada'],
      usage: 'Aplicar diariamente sobre cabello húmedo, masajear suavemente',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/shampoo-pantene-pro-v-control-de-grasa'
    });
  } else if (analysis.type === 'seco') {
    allRecommendations.push({
      id: 'pantene-hidratacion-ia',
      name: 'Pantene Pro-V Hidratación Intensa',
      type: 'shampoo',
      description: 'Análisis indica sequedad. Fórmula hidratante que restaura la humedad natural',
      benefits: ['Hidratación profunda', 'Suavidad extrema', 'Brillo radiante', 'Nutrición duradera'],
      usage: 'Aplicar 2-3 veces por semana con masaje suave',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/shampoo-pantene-pro-v-hidratacion-intensa'
    });
    allRecommendations.push({
      id: 'pantene-mascarilla-hidratante-ia',
      name: 'Pantene Pro-V Mascarilla Hidratación Intensa',
      type: 'mascarilla',
      description: 'Tratamiento intensivo recomendado para tu nivel de sequedad detectado',
      benefits: ['Hidratación 5x más intensa', 'Reparación profunda', 'Transformación visible'],
      usage: 'Aplicar 1-2 veces por semana, dejar actuar 5 minutos',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/mascarilla-pantene-pro-v-hidratacion-intensa'
    });
  }

  // Según textura detectada
  if (analysis.texture === 'rizado' || analysis.texture === 'crespo') {
    allRecommendations.push({
      id: 'pantene-rizos-ia',
      name: 'Pantene Pro-V Rizos Definidos',
      type: 'tratamiento',
      description: 'Detectamos textura rizada. Crema que define y controla sin efecto crespo',
      benefits: ['Definición perfecta', 'Control anti-frizz', 'Hidratación especializada', 'Rizos naturales'],
      usage: 'Aplicar sobre cabello húmedo, distribuir y dejar secar naturalmente',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/crema-pantene-pro-v-rizos-definidos'
    });
  }

  // Según densidad
  if (analysis.density === 'baja') {
    allRecommendations.push({
      id: 'pantene-volumen-ia',
      name: 'Pantene Pro-V Volumen y Cuerpo',
      type: 'shampoo',
      description: 'Densidad baja detectada. Fórmula que aporta volumen y cuerpo natural',
      benefits: ['Volumen desde la raíz', 'Cuerpo natural', 'Apariencia más densa', 'Textura ligera'],
      usage: 'Aplicar enfocándose en raíces, masajear y enjuagar completamente',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/shampoo-pantene-pro-v-volumen-y-cuerpo'
    });
  }

  // Según condición general
  if (analysis.condition === 'necesita_atencion' || analysis.condition === 'regular') {
    allRecommendations.push({
      id: 'pantene-reparacion-ia',
      name: 'Pantene Pro-V Reparación Total',
      type: 'tratamiento',
      description: 'Análisis indica daño. Tratamiento reparador para restaurar la salud capilar',
      benefits: ['Reparación extrema', 'Fortalecimiento', 'Protección duradera', 'Transformación visible'],
      usage: 'Aplicar en cabello húmedo, concentrar en áreas dañadas',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/tratamiento-pantene-pro-v-reparacion-total'
    });
  }

  // Siempre incluir acondicionador complementario
  const hasConditioner = allRecommendations.some(r => r.type === 'acondicionador');
  if (!hasConditioner) {
    allRecommendations.push({
      id: 'pantene-acondicionador-ia',
      name: 'Pantene Pro-V Acondicionador Nutritivo',
      type: 'acondicionador',
      description: 'Acondicionador complementario ideal para tu tipo de cabello detectado',
      benefits: ['Nutrición balanceada', 'Desenreda fácilmente', 'Suavidad duradera', 'Protección diaria'],
      usage: 'Aplicar en medios y puntas, dejar actuar 2-3 minutos',
      image: 'https://res.cloudinary.com/dewemwkqf/image/upload/v1753050423/Captura_de_Pantalla_2025-07-20_a_la_s_5.17.03_p._m._bhram9.png',
      link: 'https://www.pantenela.com/es/productos/acondicionador-pantene-pro-v-clasico'
    });
  }

  // Seleccionar solo 3 productos: 1 shampoo, 1 acondicionador, 1 tratamiento
  const finalRecommendations: ProductRecommendation[] = [];
  
  // Buscar 1 shampoo
  const shampoo = allRecommendations.find(r => r.type === 'shampoo');
  if (shampoo) finalRecommendations.push(shampoo);
  
  // Buscar 1 acondicionador
  const conditioner = allRecommendations.find(r => r.type === 'acondicionador');
  if (conditioner) finalRecommendations.push(conditioner);
  
  // Buscar 1 tratamiento (mascarilla o tratamiento)
  const treatment = allRecommendations.find(r => r.type === 'tratamiento' || r.type === 'mascarilla');
  if (treatment) finalRecommendations.push(treatment);
  
  // Si no hay suficientes productos, completar con los disponibles
  while (finalRecommendations.length < 3 && finalRecommendations.length < allRecommendations.length) {
    const remaining = allRecommendations.find(r => !finalRecommendations.includes(r));
    if (remaining) finalRecommendations.push(remaining);
  }
  
  return finalRecommendations;
};

const personalizeDescription = (description: string, analysis: HairAnalysis): string => {
  if (analysis.type === 'graso') {
    return description + ' - Especialmente formulado para cabello graso';
  } else if (analysis.type === 'seco') {
    return description + ' - Con ingredientes hidratantes extra';
  } else if (analysis.type === 'mixto') {
    return description + ' - Balance perfecto para cabello mixto';
  }
  return description;
};

const generateCareRoutine = (analysis: HairAnalysis): CareRoutine => {
  return {
    morning: [
      'Cepillar suavemente el cabello',
      'Aplicar protector térmico si usas herramientas de calor',
      'Usar aceite nutritivo en las puntas'
    ],
    evening: [
      'Cepillar el cabello antes de dormir',
      'Aplicar serum reparador si es necesario',
      'Usar funda de almohada de seda'
    ],
    weekly: [
      'Aplicar mascarilla nutritiva 1-2 veces',
      'Hacer masaje del cuero cabelludo',
      'Cortar puntas si es necesario'
    ],
    monthly: [
      'Tratamiento profesional en salón',
      'Evaluación del estado del cabello',
      'Ajustar productos según sea necesario'
    ]
  };
};

const generateTips = (analysis: HairAnalysis): string[] => {
  const baseTips = [
    'Evita el agua muy caliente al lavarte el cabello',
    'Usa herramientas de calor con moderación',
    'Protege tu cabello del sol con productos UV',
    'Mantén una dieta equilibrada rica en vitaminas',
    'Bebe suficiente agua para mantener la hidratación'
  ];

  const specificTips: Record<string, string[]> = {
    graso: [
      'Lava tu cabello con mayor frecuencia',
      'Evita tocar el cabello con las manos',
      'Usa champú seco entre lavados'
    ],
    seco: [
      'Reduce la frecuencia de lavado',
      'Usa mascarillas hidratantes regularmente',
      'Evita el cepillado excesivo'
    ],
    mixto: [
      'Aplica acondicionador solo en medios y puntas',
      'Usa productos específicos para cabello mixto',
      'Considera hacer lavados focalizados'
    ],
    normal: [
      'Mantén tu rutina actual',
      'Usa productos de mantenimiento',
      'Haz tratamientos preventivos'
    ]
  };

  return [...baseTips, ...specificTips[analysis.type]];
};